#ifndef __DELAY_H__
#define __DELAY_H__
#include "SWM181.h"

//void delay_us(uint16_t us);
void delay_ms(uint16_t ms);
//void delay_s(uint16_t s);

#endif //__DELAY_H__
